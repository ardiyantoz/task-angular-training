import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { Post } from './post.model';
import { PostService } from './post.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  loadedPosts:Post[] = [];
  endPointURL:string = 'https://angular-learn-74bca-default-rtdb.asia-southeast1.firebasedatabase.app/';
  postUrl:string = this.endPointURL+'post.json';
  isLoading:boolean = false;
  isEdit:boolean[] = [];
  editData:Post = {
    title: '',
    content: ''
  };
  $errorHandler:Subscription = Subscription.EMPTY;

  error=null;
  constructor(private http: HttpClient, private postService : PostService) {}

  ngOnInit() {
    this.$errorHandler = this.postService.errorHandling.subscribe
    (error=>{
      this.error = error;
    }
    )}

  ngOnDestroy(){
    this.$errorHandler.unsubscribe();
  }

  onCreatePost(postData: { title: string; content: string }) {
    // Send Http request
    console.log(postData);
    this.postService.createAndPost(postData);
  }

  onFetchPosts() {
    this.isLoading=true;
    // Send Http request
    this.fetchPosts();
  }

  onClearPosts() {
    // Send Http request
    this.isLoading = true;
    this.postService.deletePosts().subscribe((data)=>{
      this.isLoading = false;
      this.loadedPosts = [];
    })
  }

  openEdit(i:number){
    this.isEdit[i]=true;
    console.log(this.loadedPosts[i]);
  }

  onEditPost(post:any, id:string){
    this.postService.editPosts(post,id);
    // const data = {
    //   [id] : {
    //     content: post.contentEdit,
    //     title:post.titleEdit
    //   }
    // }
    // this.http.patch(this.postUrl,data).subscribe(data=>{
    //   console.log(data);
    // })
  }

  deleteById(index:number){
    this.isLoading = true;
    this.postService.deletePostById(this.loadedPosts[index]);
    this.fetchPosts();
  }



  private fetchPosts(){
    // this.http.get(this.postUrl).subscribe(posts=>{
    //   console.log(posts)
    // })

    this.postService.fetchPosts().subscribe(
      posts=>{
        console.log(posts);
        this.loadedPosts = posts;
        this.isLoading=false;
        for(let i = 0;i<posts.length;i++){
          this.isEdit[i]=false;
        }
      },
      error=>{
        console.log(error);
        this.error = error;
        this.isLoading=false;
      }
    )
  }


}
