import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Post } from './post.model';
import { map } from 'rxjs/operators';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class PostService {
  endPointURL:string = 'https://angular-learn-74bca-default-rtdb.asia-southeast1.firebasedatabase.app/';
  postUrl:string = this.endPointURL+'post.json';
  errorHandling = new Subject<any>();

  constructor(private http:HttpClient) { }

  createAndPost(postData:Post){
    this.http.post(this.postUrl,postData).subscribe((data)=>{
      console.log(data);
      this.errorHandling.next(null);
    },
    (error)=>{
      this.errorHandling.next(error);
    });

  }

  fetchPosts(){
    // this.http.get(this.postUrl).subscribe(posts=>{
    //   console.log(posts)
    // })
    let customParam = new HttpParams();

    customParam = customParam.append('print','pretty');
    
    customParam = customParam.append('custom-param','custom-param-value ')

    return this.http.get<{[key:string]: Post}>(this.postUrl, {headers:new HttpHeaders({
      'custom-header' : 'halo aku header'
    }),
    params: customParam}).pipe
    (map(responseData=>{
      const postArray: Post[] = [];
      for(const key in responseData){
        if(responseData.hasOwnProperty(key)){
          postArray.push({...responseData[key],id : key})
        }
      }
      return postArray;
    }))
  }

  editPosts(post:any, id:string){
    const data = {
        [id] : {
          content: post.content,
          title:post.title
        }
      }
    this.http.patch(this.postUrl,data).subscribe(data=>{
      console.log(data);
    })
  }

  deletePosts(){
    return this.http.delete(this.postUrl);
  }

  deletePostById(post:Post){
    const data= {
      [post.id]:{
        content:null,
        title:null
      }
    }
    console.log(data);
    return this.http.patch(this.postUrl,data).subscribe(data=>{
      console.log(data);
    });
  }
}
